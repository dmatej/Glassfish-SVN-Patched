/*
 * UserBean.java
 *
 * Created on October 9, 2007, 6:41 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package astrologer.user;

/**
 *
 * @author sankate
 */
public class UserBean {
    
    private String name;
    private String birthday;
    
    /** Creates a new instance of UserBean */
    public UserBean() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    
}
