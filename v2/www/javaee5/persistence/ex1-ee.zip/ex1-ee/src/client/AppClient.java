/*
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the "License").  You may not use this file except
 * in compliance with the License.
 *
 * You can obtain a copy of the license at
 * glassfish/bootstrap/legal/CDDLv1.0.txt or
 * https://glassfish.dev.java.net/public/CDDLv1.0.html.
 * See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * HEADER in each file and include the License file at
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable,
 * add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your
 * own identifying information: Portions Copyright [yyyy]
 * [name of copyright owner]
 */
package client;

import javax.ejb.*;

import java.util.Collection;
import java.util.List;

import entity.Customer;
import ejb.Test;

/**
 * @author Marina Vatkina
 */
public class AppClient {

    @EJB(name="ejb/Test") 
    private static Test sb;

    public static void main(String[] args) {
        AppClient test = new AppClient();
        test.runTest();
    }


    public void runTest() {

        // Persist all entities
        System.out.println("Inserting Customer and Orders... " + sb.testInsert());

        // Test query and navigation
        System.out.println("Verifying that all are inserted... " + sb.verifyInsert());

        // Get a detached instance 
        Customer c = sb.findCustomer("Joe Smith");

        // Remove all entities
        System.out.println("Removing all... " + sb.testDelete(c));

        // Query the results
        System.out.println("Verifying that all are removed... " + sb.verifyDelete());
    }
}
