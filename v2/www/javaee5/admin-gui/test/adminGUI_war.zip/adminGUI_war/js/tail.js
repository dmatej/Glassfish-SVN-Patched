/*
 * Copyright 2006 Sun Microsystems, Inc.  All rights reserved.
 * Use is subject to license terms.
 */

////////////////////////////////////////////////////////////////////////////
//  Tail -f JavaScript
////////////////////////////////////////////////////////////////////////////

/**
 *  jsonData must be an array of objects.  The objects are epxected to have 8 fields:
 */
function addNewTableRows(table, jsonData) {
    var row, cell, data = null;
    var arr = eval(jsonData);
    var len = arr.length - 1; // terminated w/ a dummy object
    if (!document.tail) {
	document.tail = new Object();
	document.tail.colors = ["#DDDDDD", "#FFFFFF"];
	document.tail.toggle=1;
    }
    for (var cnt=len-1; cnt != -1; cnt--) {
	data = arr[cnt];
	row = table.insertRow(1);
	row.style.backgroundColor=document.tail.colors[document.tail.toggle];
	document.tail.toggle ^= 1;
	cell = row.insertCell(0);
	cell.appendChild(document.createTextNode(unescape(data.msg)));
	cell = row.insertCell(0);
	cell.appendChild(document.createTextNode(unescape(data.logger)));
	cell = row.insertCell(0);
	cell.appendChild(document.createTextNode(unescape(data.product)));
	cell = row.insertCell(0);
	cell.appendChild(document.createTextNode(unescape(data.level)));
	cell = row.insertCell(0);
	cell.appendChild(document.createTextNode(unescape(data.id)));
    }
}

/**
 *  This function should only be called by an XMLHttpRequest callback.  It updates the 
 */
function appendContent() {
    if (document.tailReq && (document.tailReq.readyState == 4)) {
	addNewTableRows(document.tailElt, document.tailReq.responseText);
	document.tailReq = null;
	/*
	var html = document.tailReq.responseText;
	document.tailReq = null;
	html += document.tailElt.innerHTML;
	document.tailElt.innerHTML = html;
	*/
    }
}

function tailLoop(eltId) {
    var refresh = document.getElementById("form:dropDown1_list");
    window.setTimeout(
	"document.tailElt = document.getElementById('" + eltId + "'); " +
	"document.tailReq = submitAjaxRequest('" + eltId + "', 'tailRefresh=true', appendContent); " +
	"tailLoop('" + eltId + "');", refresh.options[refresh.selectedIndex].value);
}
