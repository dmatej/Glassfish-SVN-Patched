package ejb30;

import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import java.rmi.RemoteException;

/**
 * EJB 2.x style Remote Home interface
 */
public interface AdaptedHome extends EJBHome {

    public AdaptedRemote create(String id) 
        throws CreateException, RemoteException;

}
