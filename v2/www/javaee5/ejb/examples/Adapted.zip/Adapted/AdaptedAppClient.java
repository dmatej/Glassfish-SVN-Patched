package ejb30;

import javax.ejb.EJB;

public class AdaptedAppClient {

    @EJB
    private static AdaptedHome adaptedHome;

    public static void main(String args[]) {

        try {

            AdaptedRemote adapted = adaptedHome.create("duke");
            System.out.println("Adapted id = " + adapted.getId());

        } catch(Exception e) {
            e.printStackTrace();
        }

    }

}
