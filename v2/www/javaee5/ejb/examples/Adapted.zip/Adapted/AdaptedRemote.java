package ejb30;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;

/**
 * EJB 2.x style Remote Component interface
 */
public interface AdaptedRemote extends EJBObject {

    public String getId() throws RemoteException;

}
