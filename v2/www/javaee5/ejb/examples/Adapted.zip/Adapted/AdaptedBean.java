package ejb30;

import javax.ejb.Stateful;
import javax.ejb.RemoteHome;
import javax.ejb.Init;

/**
 * EJB 3.0 style bean implementation that exposes a 2.x style "adapted"
 * Home/Remote view.
 */

@Stateful
@RemoteHome(AdaptedHome.class)
public class AdaptedBean {

    private String myId = "unknown";

    @Init
    public void create(String id) {
        myId = id;
    }

    public String getId() {
        return myId;
    }

}
