package ejb30;

import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class AdaptedJavaClient {

    public static void main(String args[]) {

        try {

            InitialContext ic = new InitialContext();
            Object o = ic.lookup(AdaptedHome.class.getName());
            AdaptedHome adaptedHome = (AdaptedHome) 
                PortableRemoteObject.narrow(o, AdaptedHome.class);

            AdaptedRemote adapted = adaptedHome.create("duke");

            System.out.println("Adapted id = " + adapted.getId());

            
        } catch(Exception e) {
            e.printStackTrace();
        }


    }

}
