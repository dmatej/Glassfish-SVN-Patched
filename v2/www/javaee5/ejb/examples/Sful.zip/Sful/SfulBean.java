package ejb30;

import javax.ejb.Stateful;

@Stateful
public class SfulBean implements Sful {

    private String myId = "unknown";

    public void setId(String id) {
        myId = id;
    }

    public String getId() {
        return myId;
    }

}
