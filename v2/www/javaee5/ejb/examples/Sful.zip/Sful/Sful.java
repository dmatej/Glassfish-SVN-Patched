package ejb30;

import javax.ejb.Remote;

@Remote
public interface Sful {

    public void setId(String id);

    public String getId();

}
