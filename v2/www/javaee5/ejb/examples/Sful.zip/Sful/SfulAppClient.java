package ejb30;

import javax.ejb.EJB;

public class SfulAppClient {

    @EJB 
    private static Sful sful;

    public static void main(String args[]) {

        sful.setId("duke");
        System.out.println("Sful id = " + sful.getId());

    }

}
