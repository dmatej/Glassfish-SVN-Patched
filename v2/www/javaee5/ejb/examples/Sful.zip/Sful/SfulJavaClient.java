package ejb30;

import javax.naming.InitialContext;

public class SfulJavaClient {

    public static void main(String args[]) {

        try {

            InitialContext ic = new InitialContext();
            Sful sful = (Sful) ic.lookup("ejb30.Sful");
            sful.setId("duke");
            System.out.println("Sful id = " + sful.getId());

        } catch(Exception e) {
            e.printStackTrace();
        }

    }

}
