package ejb30;

import javax.ejb.Remote;

@Remote
public interface Sless {

    public String hello();

}
